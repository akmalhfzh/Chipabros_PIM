#!/bin/bash
# ==============================================================================
# PIM SYSTEM — DDR3 Integration Build (cpu_memory_v6)
# ==============================================================================
#
# SETUP (lakukan SEKALI sebelum pertama kali run):
#   cp ddr3_dfi_phy.v          rtl/ddr3_dfi_phy.v
#   cp pim_system_top_ddr3.v   rtl/pim_system_top.v
#   cp tb_pim_system_ddr3.v    testbench/tb_pim_system.v
#   sed -i.bak \
#     -e 's/{mem_addr\[31:6\], 6'\''b0}/{mem_addr[31:4], 4'\''b0}/g' \
#     -e 's/mem_addr\[5:2\]\*32/mem_addr[3:2]*32/g' \
#     -e 's/mem_addr\[5:2\]\*4/mem_addr[3:2]*4/g' \
#     rtl/cpu_to_axi.v
#
# TIDAK PERLU: unisims/ retarget/ glbl.v (hanya dibutuhkan untuk FPGA primitives)
# ==============================================================================

set -e

SIM_DIR="sim"
LOG_DIR="logs"
VVP_FILE="$SIM_DIR/tb_ddr3.vvp"

mkdir -p "$SIM_DIR" "$LOG_DIR"

# ─────────────────────────────────────────────────
# SANITY CHECK
# ─────────────────────────────────────────────────
echo "🔍 [0/4] Checking required files..."
MISSING=0

for f in rtl/ddr3_dfi_phy.v rtl/pim_system_top.v rtl/cpu_to_axi.v \
         rtl/pim_sparsity_aware.v rtl/simple_riscv_cpu.v rtl/pim_perf_monitor.v \
         testbench/tb_pim_system.v ddr3_micron/ddr3.v \
         core_ddr3_controller/src_v/ddr3_axi.v \
         core_ddr3_controller/src_v/ddr3_core.v \
         core_ddr3_controller/src_v/ddr3_dfi_seq.v; do
    if [ ! -f "$f" ]; then
        echo "  ❌ MISSING: $f"
        MISSING=1
    fi
done

# Cek behavioral PHY (tidak boleh ada OSERDESE2)
#if [ -f rtl/ddr3_dfi_phy.v ]; then
#    if grep -q "OSERDESE2\|ISERDESE2\|IDELAYE2" rtl/ddr3_dfi_phy.v 2>/dev/null; then
#        echo "  ❌ rtl/ddr3_dfi_phy.v masih FPGA version! Ganti dengan behavioral PHY."
#        MISSING=1
#    else
#        echo "  ✅ rtl/ddr3_dfi_phy.v = behavioral OK"
#    fi
#fi

# Cek pim_system_top sudah versi DDR3
if [ -f rtl/pim_system_top.v ]; then
    if ! grep -q "clk_ddr" rtl/pim_system_top.v 2>/dev/null; then
        echo "  ❌ rtl/pim_system_top.v masih simple_memory version! Ganti versi DDR3."
        MISSING=1
    else
        echo "  ✅ rtl/pim_system_top.v = DDR3 version OK"
    fi
fi

# Cek cpu_to_axi sudah 128-bit patch
if [ -f rtl/cpu_to_axi.v ]; then
    if grep -q "mem_addr\[31:6\]" rtl/cpu_to_axi.v 2>/dev/null; then
        echo "  ❌ rtl/cpu_to_axi.v masih 512-bit — perlu patch 128-bit"
        MISSING=1
    else
        echo "  ✅ rtl/cpu_to_axi.v = 128-bit patch OK"
    fi
fi

[ "$MISSING" -eq 1 ] && { echo ""; echo "❌ Setup belum lengkap. Lihat header script."; exit 1; }
echo ""

# ─────────────────────────────────────────────────
# 1. COMPILE
# ─────────────────────────────────────────────────
echo "🔨 [1/4] Compiling Verilog (DDR3 Behavioral PHY)..."

iverilog -g2012 \
    -o "$VVP_FILE" \
    -I ./ddr3_micron \
    -I ./core_ddr3_controller/src_v \
    \
    ddr3_micron/ddr3.v \
    \
    rtl/ddr3_dfi_phy.v \
    -y ./core_ddr3_controller/src_v \
    -y ./core_ddr3_controller/src_v/phy/xc7 \
    \
    rtl/simple_riscv_cpu.v \
    rtl/cpu_to_axi.v \
    rtl/pim_sparsity_aware.v \
    rtl/pim_system_top.v \
    rtl/pim_perf_monitor.v \
    testbench/tb_pim_system.v \
    \
    -Dden4096Mb -Dsg125 -Dx16

if [ $? -ne 0 ]; then
    echo "❌ Compile Failed!"
    exit 1
fi
echo "✅ Compile OK → $VVP_FILE"

# ─────────────────────────────────────────────────
# 2. GENERATE TESTCASES
# ─────────────────────────────────────────────────
echo ""
echo "🎲 [2/4] Generating testcases..."
python3 gen_testcase.py
echo "✅ Done"

# ─────────────────────────────────────────────────
# 3. RUN SIMULATION
# ─────────────────────────────────────────────────
echo ""
echo "🚀 [3/4] Running DDR3 sparsity sweep (timeout 10min/run)..."
echo ""

printf " %-10s | %-15s | %-15s | %-10s | %-12s | %-12s\n" \
    "SPARSITY" "BASE E (uJ)" "PIM E (uJ)" "SAVING" "SPARSE PKTS" "TOTAL PKTS"
echo "==================================================================================================="

for s in 0 25 50 75 85 90 95; do
    cp "sim_cases/firmware_sparse_${s}.hex" "$SIM_DIR/firmware.hex"

    # VVP dijalankan dari project root, firmware.hex ada di sim/
    # vvp mencari firmware.hex di cwd → pindah ke sim/ dulu
    cd "$SIM_DIR"
    timeout 600 vvp "../${VVP_FILE##*/}" > "../$LOG_DIR/log_sparse_${s}.txt" 2>&1
    EXIT_CODE=$?
    cd ..

    if [ $EXIT_CODE -eq 124 ]; then
        printf " %-10s | %-15s | %-15s | %-10s | %-12s | %-12s\n" \
            "${s}%" "TIMEOUT" "TIMEOUT" "-" "-" "-"
        continue
    fi

    LINE=$(grep "^RESULT," "$LOG_DIR/log_sparse_${s}.txt" 2>/dev/null)

    if [ -n "$LINE" ]; then
        TOTAL=$(echo "$LINE" | cut -d',' -f2)
        SPARSE=$(echo "$LINE" | cut -d',' -f3)
        BASE_E=$(echo "$LINE" | cut -d',' -f4)
        PIM_E=$(echo "$LINE" | cut -d',' -f5)
        SAVE=$(echo "$LINE" | cut -d',' -f6)
        printf " %-10s | %-15s | %-15s | %-10s | %-12s | %-12s\n" \
            "${s}%" "$BASE_E" "$PIM_E" "$SAVE" "$SPARSE" "$TOTAL"
    else
        printf " %-10s | %-15s | %-15s | %-10s | %-12s | %-12s\n" \
            "${s}%" "ERR" "ERR" "ERR" "ERR" "ERR"
        echo "   → $LOG_DIR/log_sparse_${s}.txt"
    fi
done

echo "==================================================================================================="
echo ""
echo "📁 [4/4] Logs: $LOG_DIR/"
